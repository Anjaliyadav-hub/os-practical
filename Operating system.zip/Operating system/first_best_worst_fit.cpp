
#include <iostream>
using namespace std;

int main()
{
    int nb, np;
    int block[20], process[20];

    cout << "Enter number of memory blocks: ";
    cin >> nb;

    cout << "Enter size of memory blocks:\n";
    for (int i = 0; i < nb; i++)
        cin >> block[i];

    cout << "Enter number of processes: ";
    cin >> np;

    cout << "Enter size of processes:\n";
    for (int i = 0; i < np; i++)
        cin >> process[i];

    // First Fit
    int b1[20];
    for (int i = 0; i < nb; i++)
        b1[i] = block[i];

    cout << "\nFirst Fit Allocation:\n";
    for (int i = 0; i < np; i++)
    {
        int j;
        for (j = 0; j < nb; j++)
        {
            if (b1[j] >= process[i])
            {
                cout << "Process " << i + 1
                     << " allocated to Block " << j + 1 << endl;
                b1[j] -= process[i];
                break;
            }
        }
        if (j == nb)
            cout << "Process " << i + 1 << " not allocated\n";
    }

    // Best Fit
    int b2[20];
    for (int i = 0; i < nb; i++)
        b2[i] = block[i];

    cout << "\nBest Fit Allocation:\n";
    for (int i = 0; i < np; i++)
    {
        int best = -1;
        for (int j = 0; j < nb; j++)
        {
            if (b2[j] >= process[i])
            {
                if (best == -1 || b2[j] < b2[best])
                    best = j;
            }
        }

        if (best != -1)
        {
            cout << "Process " << i + 1
                 << " allocated to Block " << best + 1 << endl;
            b2[best] -= process[i];
        }
        else
            cout << "Process " << i + 1 << " not allocated\n";
    }

    // Worst Fit
    int b3[20];
    for (int i = 0; i < nb; i++)
        b3[i] = block[i];

    cout << "\nWorst Fit Allocation:\n";
    for (int i = 0; i < np; i++)
    {
        int worst = -1;
        for (int j = 0; j < nb; j++)
        {
            if (b3[j] >= process[i])
            {
                if (worst == -1 || b3[j] > b3[worst])
                    worst = j;
            }
        }

        if (worst != -1)
        {
            cout << "Process " << i + 1
                 << " allocated to Block " << worst + 1 << endl;
            b3[worst] -= process[i];
        }
        else
            cout << "Process " << i + 1 << " not allocated\n";
    }

    return 0;
}
