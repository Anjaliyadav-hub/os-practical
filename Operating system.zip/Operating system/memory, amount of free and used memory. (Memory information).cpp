
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{
    ifstream file("main.cpp");
    string line;

    long total = 0, free = 0, available = 0;

    if (!file)
    {
        cout << "Unable to open memory information file";
        return 1;
    }

    while (getline(file, line))
    {
        if (line.find("MemTotal:") == 0)
            total = stol(line.substr(9));

        else if (line.find("MemFree:") == 0)
            free = stol(line.substr(8));

        else if (line.find("MemAvailable:") == 0)
            available = stol(line.substr(13));
    }

    cout << "Total Configured Memory: "
         << total / 1024 << " MB" << endl;

    cout << "Free Memory: "
         << free / 1024 << " MB" << endl;

    cout << "Available Memory: "
         << available / 1024 << " MB" << endl;

    cout << "Used Memory: "
         << (total - available) / 1024 << " MB" << endl;

    file.close();

    return 0;
}
