
#include <iostream>
#include <sys/utsname.h>
#include <fstream>
using namespace std;

int main()
{
    struct utsname info;

    if (uname(&info) == -1)
    {
        cout << "Error getting system information";
        return 1;
    }

    cout << "----- Linux Kernel Information -----\n";

    cout << "Kernel Name    : " << info.sysname << endl;
    cout << "Kernel Version : " << info.release << endl;
    cout << "Machine Type   : " << info.machine << endl;

    cout << "\n----- CPU Information -----\n";

    ifstream file("/proc/cpuinfo");

    if (!file)
    {
        cout << "CPU information file not available";
        return 1;
    }

    string line;

    while (getline(file, line))
    {
        if (line.find("model name") != string::npos ||
            line.find("processor") != string::npos ||
            line.find("cpu cores") != string::npos)
        {
            cout << line << endl;
        }
    }

    file.close();

    return 0;
}
