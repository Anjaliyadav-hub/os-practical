
#include <iostream>
#include <pthread.h>
using namespace std;

int n, sum = 0;
int arr[100];

void* calculateSum(void* arg)
{
    for (int i = 0; i < n; i++)
    {
        sum = sum + arr[i];
    }

    pthread_exit(NULL);
}

int main()
{
    pthread_t thread;

    cout << "Enter number of elements: ";
    cin >> n;

    cout << "Enter " << n << " numbers:\n";

    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }

    pthread_create(&thread, NULL, calculateSum, NULL);

    pthread_join(thread, NULL);

    cout << "Sum of numbers = " << sum << endl;

    return 0;
}
