
#include <iostream>
using namespace std;

int main()
{
    int n, bt[20], wt[20], tat[20], p[20];

    cout << "Enter number of processes: ";
    cin >> n;

    cout << "Enter burst time of processes:\n";

    for (int i = 0; i < n; i++)
    {
        p[i] = i + 1;
        cout << "P" << p[i] << ": ";
        cin >> bt[i];
    }

    // Sorting processes according to burst time
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (bt[i] > bt[j])
            {
                swap(bt[i], bt[j]);
                swap(p[i], p[j]);
            }
        }
    }

    wt[0] = 0;

    for (int i = 1; i < n; i++)
    {
        wt[i] = wt[i - 1] + bt[i - 1];
    }

    for (int i = 0; i < n; i++)
    {
        tat[i] = wt[i] + bt[i];
    }

    cout << "\nProcess\tBurst Time\tWaiting Time\tTurnaround Time\n";

    for (int i = 0; i < n; i++)
    {
        cout << "P" << p[i] << "\t"
             << bt[i] << "\t\t"
             << wt[i] << "\t\t"
             << tat[i] << endl;
    }

    return 0;
}
