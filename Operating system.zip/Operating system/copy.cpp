
#include <iostream>
#include <fcntl.h>
#include <unistd.h>
using namespace std;

int main()
{
    int source, destination;
    char buffer[1024];
    int bytes;

    source = open("source.txt", O_RDONLY);

    if (source < 0)
    {
        cout << "Error opening source file";
        return 1;
    }

    destination = open("destination.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);

    if (destination < 0)
    {
        cout << "Error creating destination file";
        close(source);
        return 1;
    }

    while ((bytes = read(source, buffer, sizeof(buffer))) > 0)
    {
        write(destination, buffer, bytes);
    }

    close(source);
    close(destination);

    cout << "File copied successfully!";

    return 0;
}
