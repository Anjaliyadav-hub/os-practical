

#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
using namespace std;

int main()
{
    pid_t pid = fork();

    if (pid < 0)
    {
        cout << "Fork failed!" << endl;
    }

    // i. Same program, same code
    else if (pid == 0)
    {
        cout << "Child Process: Same code executed" << endl;
    }
    else
    {
        cout << "Parent Process: Same code executed" << endl;
    }

    // ii. Same program, different code
    if (pid == 0)
    {
        cout << "Child Process: Different code executed" << endl;
    }
    else if (pid > 0)
    {
        cout << "Parent Process: Different code executed" << endl;
    }

    // iii. Parent waits for child
    if (pid > 0)
    {
        wait(NULL);
        cout << "Parent: Child process completed." << endl;
    }
    else if (pid == 0)
    {
        cout << "Child: Finishing task." << endl;
    }

    return 0;
}
